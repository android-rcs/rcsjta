var NAVTREE_GUIDES =
[ 
	[ "Guides", "guides/index.html", [ 
		[ "Get to know joyn services via the RI application", "guides/getToKnow.html",null,""],
		[ "How to initialise a chat", "guides/initChat.html",null,""],
		[ "Create a new capacity extension", "guides/createExtension.html",null,""],
		[ "Get list of online contacts", "guides/listContacts.html",null,""],
		[ "Detect if joyn services our started", "guides/detectServices.html",null,""]
	], "" ] 
];


